import os
from datetime import datetime

import ydb

from logger import logger

YD_ENDPOINT = os.getenv(key="YD_ENDPOINT")
YD_PATH = os.getenv(key="YD_PATH")
YD_PATH_TOKEN = os.getenv(key="YD_PATH_TOKEN")


class DbHandler:
    def __init__(self):
        driver_config = ydb.DriverConfig(
            endpoint=YD_ENDPOINT,
            database=YD_PATH,
            credentials=ydb.credentials_from_env_variables(),
            root_certificates=ydb.load_ydb_root_certificate(),
        )

        self.driver = ydb.Driver(driver_config)
        try:
            self.driver.wait(timeout=15)
        except TimeoutError:
            logger.warn(f"Connect failed to YDB: {self.driver.discovery_debug_details()}")

    def add_user(self,user_id, username, first_name):
        session = self.driver.table_client.session().create()
        if self.user_exists(user_id):
            return

        query = f"""
            INSERT INTO Users (user_id, username, first_name, total_albums, last_listened)
            VALUES ({user_id}, '{username}', '{first_name}', 0, CAST(0 AS Timestamp))
            """

        session.transaction().execute(
            query,
            commit_tx=True
        )
        logger.info(f"User {user_id} successfully added to DB")

    def add_album(self, image_url, title, description):
        session = self.driver.table_client.session().create()
        last_id = self.get_album_with_max_id()
        if last_id is None:
            last_id = 1
        session.transaction(ydb.SerializableReadWrite()).execute(
            f"""
            INSERT INTO Albums (album_id, image_url, title, description)
            VALUES ({last_id}, '{image_url}', '{title}', '{description}')
            """
        )

    def get_album_with_max_id(self):
        session = self.driver.table_client.session().create()

        query_result = session.transaction(ydb.SerializableReadWrite()).execute(
            """
            SELECT album_id, image_url, title, description
            FROM Albums
            ORDER BY album_id DESC
            LIMIT 1
            """
        )

        if not query_result:
            print("No albums found.")
            return None

        min_album = query_result[0].rows
        return min_album['album_id']

    def user_exists(self, user_id):
        session = self.driver.table_client.session().create()
        result = session.transaction(ydb.SerializableReadWrite()).execute(
            f"""
            SELECT 1 FROM Users WHERE user_id = {user_id} LIMIT 1;
            """,
            commit_tx=True,
            settings=ydb.BaseRequestSettings().with_timeout(3).with_operation_timeout(2),
        )
        return len(result[0].rows) == 1