import json
import os
import random

from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

from db import DbHandler
from logger import logger
from albums import get_albums

GET_AN_ALBUM = "Получить альбом"
LISTENED_ALBUMS = "Прослушанные альбомы"
SETTINGS = "Настройки"

urls_albums = ['https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/arcade-fire-%ef%bb%bffuneral-1062733/',
         'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/linda-mccartney-and-paul-ram-1062783/',
       #     400   'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/the-go-gos-beauty-and-the-beat-1062833/',
        #    350   'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/stevie-wonder-music-of-my-mind-2-1062883',
         #   300   'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/shania-twain-come-on-over-1062933/',
          #  250   'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/buzzcocks-singles-going-steady-2-1062983',
           #    'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/sade-diamond-life-1063033',
            #   'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/bruce-springsteen-nebraska-3-1063083/',
               #'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/the-band-music-from-big-pink-2-1063133/',
               #'https://www.rollingstone.com/music/music-lists/best-albums-of-all-time-1062063/jay-z-the-blueprint-3-1063183/'
               ]
all_albums = []

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await  update.effective_message.reply_text("Hi")
    username = update.message.from_user.username
    first_name = update.message.from_user.first_name
    user_id = update.message.from_user.id
    DbHandler().add_user(user_id, username, first_name)

    buttons = [[KeyboardButton(GET_AN_ALBUM)], [KeyboardButton(LISTENED_ALBUMS), KeyboardButton(SETTINGS)]]
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="Добро пожаловать в Top 500 Greatest Albums of All time!",
        reply_markup=ReplyKeyboardMarkup(buttons, resize_keyboard=True, ),
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text: str = update.message.text

    # Free card processing
    if GET_AN_ALBUM in text:
        all_albumss = get_albums(urls_albums)
        random_element = random.choice(all_albumss)
        text_message = f"{random_element[2]} ({random_element[1]})\n\n{random_element[3]}"

        await update.message.reply_photo(photo=random_element[0], caption=text_message, parse_mode=ParseMode.HTML)
    if "GO" in text:
        data = text.split()
        links = [data[1]]
        get_albums(links, int(data[2]))

class TgHandler:
    def __init__(self):
        BOT_TOKEN = os.getenv(key="BOT_TOKEN", default="7086079456:AAHI7NWCKBedxLT9-cnsoA0IVqB2oaK-VL0")
        self.application = ApplicationBuilder().token(BOT_TOKEN).build()
        self.add_user_handlers()
    def add_user_handlers(self):
        # /start and /help handler
        self.application.add_handler(CommandHandler("start", start_command))

        # Message handler
        self.application.add_handler(MessageHandler(filters.TEXT, handle_message))

    def local_run(self):
        print("Starting bot...")

        self.application.run_polling()

    async def cloud_run(self, event):
        try:
            logger.info('Processing update...')
            await self.application.initialize()
            for message in event["messages"]:
                await self.application.process_update(
                    Update.de_json(json.loads(message["details"]["message"]["body"]), self.application.bot)
                )
                logger.info(f'Processed update {message["details"]["message"]["body"]}')
                return 'Success'
        except Exception as e:
            logger.info(f"Failed to process update with {e}")
        return 'Failure'
